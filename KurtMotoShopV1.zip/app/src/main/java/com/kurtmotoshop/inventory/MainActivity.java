package com.kurtmotoshop.inventory;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    private final ArrayList<Product> products = new ArrayList<>();
    private LinearLayout listContainer;
    private EditText search;
    private TextView totalProducts, totalStock;
    private static final int PICK_IMAGE = 41;
    private String pendingImagePath = "";

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        products.addAll(InventoryStore.load(this));
        buildUi();
        renderProducts();
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView tv(String text, float size, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(44));
        b.setBackground(bg(Color.rgb(255,49,49), 12));
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(10));
        root.setBackgroundColor(Color.rgb(8,9,13));

        TextView title = tv("KURT MOTOSHOP", 24, Color.WHITE);
        title.setTypeface(null, 1);
        TextView sub = tv("INVENTORY  •  OFFLINE MODE", 11, Color.rgb(255,80,80));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(34)));
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(25)));

        LinearLayout stats = new LinearLayout(this);
        stats.setPadding(0, dp(6), 0, dp(8));
        stats.setOrientation(LinearLayout.HORIZONTAL);
        totalProducts = tv("", 14, Color.WHITE);
        totalStock = tv("", 14, Color.WHITE);
        stats.addView(card("PRODUCTS", totalProducts), new LinearLayout.LayoutParams(0, dp(68), 1));
        LinearLayout.LayoutParams s = new LinearLayout.LayoutParams(0, dp(68), 1);
        s.setMargins(dp(8),0,0,0);
        stats.addView(card("TOTAL STOCK", totalStock), s);
        root.addView(stats);

        search = new EditText(this);
        search.setSingleLine();
        search.setHint("Search products...");
        search.setHintTextColor(Color.GRAY);
        search.setTextColor(Color.WHITE);
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(bg(Color.rgb(24,26,33), 12));
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){ renderProducts(); }
            public void afterTextChanged(android.text.Editable e){}
        });
        root.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));

        Button add = button("+  ADD PRODUCT");
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(48));
        ap.setMargins(0, dp(9), 0, dp(9));
        root.addView(add, ap);
        add.setOnClickListener(v -> showProductDialog(null));

        ScrollView scroll = new ScrollView(this);
        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    private LinearLayout card(String label, TextView value) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(12), dp(6), dp(12), dp(6));
        c.setBackground(bg(Color.rgb(24,26,33), 12));
        TextView l = tv(label, 9, Color.GRAY);
        c.addView(l, new LinearLayout.LayoutParams(-1, dp(20)));
        c.addView(value, new LinearLayout.LayoutParams(-1, dp(30)));
        return c;
    }

    private void renderProducts() {
        if (listContainer == null) return;
        listContainer.removeAllViews();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase();
        int stockTotal = 0, shown = 0;
        for (Product p : products) stockTotal += p.stock;
        totalProducts.setText(String.valueOf(products.size()));
        totalStock.setText(String.valueOf(stockTotal));

        for (Product p : products) {
            if (!p.name.toLowerCase().contains(q)) continue;
            shown++;
            listContainer.addView(productRow(p));
        }
        if (shown == 0) {
            TextView empty = tv(products.isEmpty() ? "No products yet. Tap + ADD PRODUCT." : "No matching products.", 14, Color.GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, dp(35), 0, dp(35));
            listContainer.addView(empty);
        }
    }

    private LinearLayout productRow(Product p) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), dp(8), dp(8), dp(8));
        row.setBackground(bg(Color.rgb(20,22,28), 14));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(92));
        rp.setMargins(0, 0, 0, dp(8));
        row.setLayoutParams(rp);

        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackground(bg(Color.rgb(35,37,44), 10));
        if (p.imagePath != null && !p.imagePath.isEmpty()) {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 4;
            img.setImageBitmap(BitmapFactory.decodeFile(p.imagePath, o));
        }
        row.addView(img, new LinearLayout.LayoutParams(dp(74), dp(74)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12),0,dp(5),0);
        TextView name = tv(p.name, 15, Color.WHITE);
        name.setTypeface(null,1);
        TextView price = tv(String.format(Locale.US, "₱%,.2f", p.price), 13, Color.rgb(255,100,100));
        TextView stock = tv("Stock: " + p.stock, 12, p.stock <= 3 ? Color.rgb(255,170,60) : Color.LTGRAY);
        info.addView(name, new LinearLayout.LayoutParams(-1, dp(28)));
        info.addView(price, new LinearLayout.LayoutParams(-1, dp(23)));
        info.addView(stock, new LinearLayout.LayoutParams(-1, dp(23)));
        row.addView(info, new LinearLayout.LayoutParams(0, -1, 1));

        TextView edit = tv("⋮", 28, Color.WHITE);
        edit.setGravity(Gravity.CENTER);
        edit.setOnClickListener(v -> showActions(p));
        row.addView(edit, new LinearLayout.LayoutParams(dp(40), dp(60)));

        return row;
    }

    private void showActions(Product p) {
        final String[] actions = {"Edit", "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(p.name)
                .setItems(actions, (d, which) -> {
                    if (which == 0) showProductDialog(p);
                    else confirmDelete(p);
                }).show();
    }

    private void confirmDelete(Product p) {
        new AlertDialog.Builder(this)
                .setTitle("Delete product?")
                .setMessage("Remove \"" + p.name + "\" from inventory?")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d,w) -> {
                    products.remove(p);
                    InventoryStore.save(this, products);
                    renderProducts();
                }).show();
    }

    private void showProductDialog(Product edit) {
        pendingImagePath = edit == null ? "" : (edit.imagePath == null ? "" : edit.imagePath);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), dp(2));

        EditText name = field("Product name");
        EditText price = field("Price (₱)");
        EditText stock = field("Stock quantity");
        price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        stock.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        if (edit != null) {
            name.setText(edit.name);
            price.setText(String.valueOf(edit.price));
            stock.setText(String.valueOf(edit.stock));
        }
        box.addView(name);
        box.addView(price);
        box.addView(stock);

        Button image = button("📷  SELECT PRODUCT IMAGE");
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, dp(46));
        ip.setMargins(0, dp(8), 0, 0);
        box.addView(image, ip);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(edit == null ? "Add Product" : "Edit Product")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton(edit == null ? "Add" : "Save", null)
                .create();

        image.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_IMAGE);
        });

        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            if (n.isEmpty()) { name.setError("Required"); return; }
            try {
                double pr = Double.parseDouble(price.getText().toString().trim());
                int st = Integer.parseInt(stock.getText().toString().trim());
                if (edit == null) {
                    products.add(new Product(UUID.randomUUID().toString(), n, pr, st, pendingImagePath));
                } else {
                    edit.name = n; edit.price = pr; edit.stock = st; edit.imagePath = pendingImagePath;
                }
                InventoryStore.save(this, products);
                renderProducts();
                dialog.dismiss();
            } catch (Exception e) {
                Toast.makeText(this, "Enter valid price and stock.", Toast.LENGTH_SHORT).show();
            }
        }));
        dialog.show();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.GRAY);
        e.setTextColor(Color.WHITE);
        e.setSingleLine();
        e.setPadding(dp(12),0,dp(12),0);
        e.setBackground(bg(Color.rgb(24,26,33), 10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(48));
        p.setMargins(0, dp(5), 0, dp(5));
        e.setLayoutParams(p);
        return e;
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                InputStream in = getContentResolver().openInputStream(uri);
                File out = new File(getFilesDir(), "img_" + System.currentTimeMillis() + ".jpg");
                FileOutputStream fos = new FileOutputStream(out);
                byte[] buf = new byte[8192];
                int len;
                while ((len = in.read(buf)) > 0) fos.write(buf,0,len);
                fos.close(); in.close();
                pendingImagePath = out.getAbsolutePath();
                Toast.makeText(this, "Image selected.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not load image.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
