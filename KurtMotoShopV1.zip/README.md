# Kurt MotoShop V1

Offline-first Android inventory app for a motorcycle shop.

## Features
- Add, edit, and delete products
- Product name, price, stock
- Product image stored locally in app storage
- Search products
- Product count and total stock dashboard
- Offline local persistence
- Racing-inspired dark UI
- GitHub Actions APK build

## Build on GitHub
1. Create a GitHub repository.
2. Upload all files from this project.
3. Push to `main` or `master`.
4. Open **Actions**.
5. Select **Build Kurt MotoShop V1 APK**.
6. Download the `Kurt-MotoShop-V1-APK` artifact.

## Next version ideas
- Cloud sync when internet is available
- Stock-in / stock-out history
- Barcode scanner
- Categories
- Supplier records
- Sales and profit dashboard
- Admin PIN
